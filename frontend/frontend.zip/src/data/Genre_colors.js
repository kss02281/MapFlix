const Genre_colors = {
    'Comedy':'#FFFF96',
    'Adventure':'#FFE650',
    'Talk-Show':'#FFE5CB',
    'Family':'#FFCAD5',
    'Animation':'#FFB900',
    'Reality-TV':'#FF9E9B',
    'Romance':'#FF88A7',
    'Action':'#FF6666',
    'Musical':'#FF5675',
    'Western':'#F0B469',
    'Sci-Fi':'#DDDDDD',
    'War':'#D27D32',
    'Crime':'#CAB2DB',
    'Thriller':'#BECDFF',
    'Fantasy':'#ACF3FF',
    'Horror':'#AAEBAA',
    'Biography':'#A8F552',
    'Mystery':'#9D71BD',
    'Drama':'#93DAFF',
    'Documentary':'#78A9ED',
    'News':'#68D168',
    'Game-Show':'#65FFBA',
    'Military':'#369F36',
    'History':'#14D3FF',
    'Sport':'#00BFFF'
  }

  export {Genre_colors};